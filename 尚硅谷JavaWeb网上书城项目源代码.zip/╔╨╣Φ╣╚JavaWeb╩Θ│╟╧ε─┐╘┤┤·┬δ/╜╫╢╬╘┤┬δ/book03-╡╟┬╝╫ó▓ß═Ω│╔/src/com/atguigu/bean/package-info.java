/**
 * 
 */
/**
 * @author wzg
 *
 */
package com.atguigu.bean;