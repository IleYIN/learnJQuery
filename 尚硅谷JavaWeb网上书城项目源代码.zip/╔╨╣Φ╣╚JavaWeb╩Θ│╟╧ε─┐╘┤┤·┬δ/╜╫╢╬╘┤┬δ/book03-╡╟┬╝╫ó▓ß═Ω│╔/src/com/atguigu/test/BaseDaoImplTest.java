package com.atguigu.test;

import org.junit.Test;

import com.atguigu.dao.impl.UserDaoImpl;

public class BaseDaoImplTest {

	@Test
	public void testBaseDaoImpl() {
		new UserDaoImpl();
	}
	
}
